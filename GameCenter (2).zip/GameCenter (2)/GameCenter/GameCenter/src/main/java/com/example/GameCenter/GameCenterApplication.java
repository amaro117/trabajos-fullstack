package com.example.GameCenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameCenterApplication.class, args);
	}

}
